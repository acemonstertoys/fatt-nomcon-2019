The job of the hardware board is adapt a commodity board to customizable buttons
and actuators.  Currently there is only one board:

## Pi Hat 1
![Board image](pi-hat-1/board.png)

A custom Pi hat which is pretty simple to build (we held intro soldering classes
around it).  The board takes 12V in, powers the Pi under it, and switches 12V
for lights on buttons (up to six of them), a high-current output for external
relays, and two small relays intended for volt-free switching.
